<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Users</h3>

                    <div class="box-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>ID</th>
                            <th> Post Title</th>
                            <th>User name</th>
                            <th>comments</th>
                            <th>Status</th>
                            <th>time</th>
                            <th>seen</th>
                            <th>answer </th>
                        </tr>
                        <?php foreach($comments as $comment): ?>
                            <tr>
                                <td><?php echo e($comment->id); ?></td>
                                <td><?php echo e($comment->post->title); ?></td>
                                <td><?php echo e($comment->name); ?></td>
                                <td><?php echo e($comment->body); ?></td>
                                <?php if($comment->seen==0): ?>
                                <td><span class="label label-primary">new</span></td>
                                    <td><?php echo e($comment->created_at->diffForHumans()); ?></td>
                                    <td><a class="label label-warning" href="<?php echo e(url("/admin/comments/".$comment->id."/seen")); ?>">Seen</a></td>
                                <?php else: ?>
                                    <td><span class="label label-primary">old</span></td>
                                    <td><?php echo e($comment->created_at->diffForHumans()); ?></td>
                                    <td><a class="label label-warning" href="<?php echo e(url("/admin/comments/".$comment->id."/seen")); ?>">UnSeen</a></td>
                                <?php endif; ?>



                              

                            </tr>
                        <?php endforeach; ?>


                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminPanel.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>