<?php $__env->startSection('content'); ?>

  <form action="<?php echo e(url('/admin/post/'.$post->id)); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <input type="text" name="body" value="<?php echo e($post->body); ?>" >
      <input type="text" name="title" value=" <?php echo e($post->title); ?>">
      <input type="submit">
  </form>


    <?php echo e($post->title); ?>

    <?php echo e($post->body); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminPanel.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>