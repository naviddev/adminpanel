<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Users</h3>

                    <div class="box-tools">
                        <div class="input-group input-group-sm" style="width: 150px;">
                            <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>name</th>
                            <th>Status</th>
                            <th>Last online</th>
                            <th>Age</th>
                            <th>vip</th>
                        </tr>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->FName); ?> <?php echo e($user->LName); ?></td>
                            <?php if($user->vip==1): ?>
                                <td><span class="label label-warning">vip</span></td>
                                <?php else: ?>
                                <td><span class="label label-primary">Normal</span></td>
                                <?php endif; ?>
                            <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                            <td><?php echo e($user->updated_at->diffForHumans()); ?></td>


                            <td><a class="label label-warning" href="<?php echo e(url("/admin/users/vip/".$user->id)); ?>">vip</a></td>
                        </tr>
                        <?php endforeach; ?>


                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminPanel.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>