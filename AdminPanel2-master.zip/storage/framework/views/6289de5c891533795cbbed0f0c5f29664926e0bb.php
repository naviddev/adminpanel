<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('/admin/post/add')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="text" placeholder="title" name="title">
        <input type="text" placeholder="body" name="body">
        <input type="submit">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminPanel.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>