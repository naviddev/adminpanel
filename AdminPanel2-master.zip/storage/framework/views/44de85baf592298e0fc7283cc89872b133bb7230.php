<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3">
            <a href="<?php echo e(url('/admin/mail/compose')); ?>" class="btn btn-primary btn-block margin-bottom">Compose</a>

            <div class="box box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title">Folders</h3>

                    <div class="box-tools">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body no-padding">
                    <ul class="nav nav-pills nav-stacked">
                        <li class="active"><a href="<?php echo e(url('/admin/mail/inbox')); ?>"><i class="fa fa-inbox"></i> Inbox
                                <span class="label label-primary pull-right"><?php echo e(counter(Auth::guard('admin')->user()->mails)); ?></span></a></li>
                        <li><a href="<?php echo e(url('/admin/mail/sent')); ?>"><i class="fa fa-envelope-o"></i> Sent</a></li>

                    </ul>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /. box -->
            <div class="box box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"></h3>

                    <div class="box-tools">

                        </button>
                    </div>
                </div>
                <div class="box-body no-padding">

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Inbox</h3>

                    <div class="box-tools pull-right">
                        <div class="has-feedback">
                            <input type="text" class="form-control input-sm" placeholder="Search Mail">
                            <span class="glyphicon glyphicon-search form-control-feedback"></span>
                        </div>
                    </div>
                    <!-- /.box-tools -->
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <div class="mailbox-controls">
                        <!-- Check all button -->

                    </div>
                    <div class="table-responsive mailbox-messages">
                        <table class="table table-hover table-striped">
                            <tbody>
                            <?php foreach($mails as $mail): ?>
                                <?php if($mail->read==0): ?>
                            <tr>
                                <td><a href="<?php echo e(url('/admin/inbox/'.$mail->id.'/delete')); ?>"><i class="fa fa-trash-o"></i></a></td>
                                <td class="mailbox-star"><a href="#"><i class="<?php echo e(mailType($mail->type)); ?>"></i></a></td>

                                <td class="mailbox-name"><a href="<?php echo e(url('/admin/inbox/'.$mail->id)); ?>"><?php echo e($mail->sender); ?></a></td>
                                <td class="mailbox-subject"><b><?php echo e($mail->subject); ?></b> - <?php echo e(get_excerpt($mail->body)); ?>

                                </td>
                                <td class="mailbox-attachment"></td>
                                <td class="mailbox-date"><?php echo e($mail->created_at->diffForHumans()); ?></td>

                            <?php endif; ?>
<?php endforeach; ?>




                            </tbody>
                        </table>
                        <!-- /.table -->
                    </div>
                    <!-- /.mail-box-messages -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer no-padding">
                    <div class="mailbox-controls">

                        </div>
                        <!-- /.pull-right -->
                    </div>
                </div>
            </div>
            <!-- /. box -->
        </div>
        <!-- /.col -->
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminPanel.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>